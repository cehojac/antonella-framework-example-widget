<?php
namespace VWXYZ;

class Init
{
    public function __construct()
    {

    }

    public static function index()
    {

    }
}
