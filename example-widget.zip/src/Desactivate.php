<?php
namespace VWXYZ;

class Desactivate
{
    /*
    *
    */
    public function index()
    {

    }
}
